﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblValorDeA = new System.Windows.Forms.Label();
            this.lblValorDeB = new System.Windows.Forms.Label();
            this.lblValorDeC = new System.Windows.Forms.Label();
            this.txtValorDeA = new System.Windows.Forms.TextBox();
            this.txtValorDeB = new System.Windows.Forms.TextBox();
            this.txtValorDeC = new System.Windows.Forms.TextBox();
            this.btnExecuta = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblValorDeA
            // 
            this.lblValorDeA.AutoSize = true;
            this.lblValorDeA.Location = new System.Drawing.Point(41, 33);
            this.lblValorDeA.Name = "lblValorDeA";
            this.lblValorDeA.Size = new System.Drawing.Size(56, 13);
            this.lblValorDeA.TabIndex = 0;
            this.lblValorDeA.Text = "Valor de A";
            // 
            // lblValorDeB
            // 
            this.lblValorDeB.AutoSize = true;
            this.lblValorDeB.Location = new System.Drawing.Point(44, 88);
            this.lblValorDeB.Name = "lblValorDeB";
            this.lblValorDeB.Size = new System.Drawing.Size(56, 13);
            this.lblValorDeB.TabIndex = 1;
            this.lblValorDeB.Text = "Valor de B";
            // 
            // lblValorDeC
            // 
            this.lblValorDeC.AutoSize = true;
            this.lblValorDeC.Location = new System.Drawing.Point(44, 143);
            this.lblValorDeC.Name = "lblValorDeC";
            this.lblValorDeC.Size = new System.Drawing.Size(56, 13);
            this.lblValorDeC.TabIndex = 2;
            this.lblValorDeC.Text = "Valor de C";
            // 
            // txtValorDeA
            // 
            this.txtValorDeA.Location = new System.Drawing.Point(160, 33);
            this.txtValorDeA.Name = "txtValorDeA";
            this.txtValorDeA.Size = new System.Drawing.Size(100, 20);
            this.txtValorDeA.TabIndex = 3;
            this.txtValorDeA.Validating += new System.ComponentModel.CancelEventHandler(this.txtValorDeA_Validating);
            // 
            // txtValorDeB
            // 
            this.txtValorDeB.Location = new System.Drawing.Point(160, 88);
            this.txtValorDeB.Name = "txtValorDeB";
            this.txtValorDeB.Size = new System.Drawing.Size(100, 20);
            this.txtValorDeB.TabIndex = 4;
            this.txtValorDeB.Validating += new System.ComponentModel.CancelEventHandler(this.txtValorDeB_Validating);
            // 
            // txtValorDeC
            // 
            this.txtValorDeC.Location = new System.Drawing.Point(160, 143);
            this.txtValorDeC.Name = "txtValorDeC";
            this.txtValorDeC.Size = new System.Drawing.Size(100, 20);
            this.txtValorDeC.TabIndex = 5;
            this.txtValorDeC.Validating += new System.ComponentModel.CancelEventHandler(this.txtValorDeC_Validating);
            // 
            // btnExecuta
            // 
            this.btnExecuta.Location = new System.Drawing.Point(108, 255);
            this.btnExecuta.Name = "btnExecuta";
            this.btnExecuta.Size = new System.Drawing.Size(75, 23);
            this.btnExecuta.TabIndex = 6;
            this.btnExecuta.Text = "Executa";
            this.btnExecuta.UseVisualStyleBackColor = true;
            this.btnExecuta.Click += new System.EventHandler(this.btnExecuta_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(314, 255);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 7;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnExecuta);
            this.Controls.Add(this.txtValorDeC);
            this.Controls.Add(this.txtValorDeB);
            this.Controls.Add(this.txtValorDeA);
            this.Controls.Add(this.lblValorDeC);
            this.Controls.Add(this.lblValorDeB);
            this.Controls.Add(this.lblValorDeA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblValorDeA;
        private System.Windows.Forms.Label lblValorDeB;
        private System.Windows.Forms.Label lblValorDeC;
        private System.Windows.Forms.TextBox txtValorDeA;
        private System.Windows.Forms.TextBox txtValorDeB;
        private System.Windows.Forms.TextBox txtValorDeC;
        private System.Windows.Forms.Button btnExecuta;
        private System.Windows.Forms.Button btnSair;
    }
}

