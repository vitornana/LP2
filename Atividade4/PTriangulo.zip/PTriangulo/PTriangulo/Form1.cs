﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double valorDeA, valorDeB, valorDeC;

        private void txtValorDeB_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtValorDeB.Text, out valorDeB) || valorDeB <= 0)
            {
                MessageBox.Show("Valor de B inválido");
                e.Cancel = true;
            }
        }

        private void txtValorDeC_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtValorDeC.Text, out valorDeC) || valorDeC <= 0)
            {
                MessageBox.Show("Valor de C inválido");
                e.Cancel = true;
            }
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            if ((valorDeA < valorDeB + valorDeC) && (valorDeA > Math.Abs(valorDeB - valorDeC)) && (valorDeB < (valorDeA + valorDeC)) && (valorDeB > Math.Abs(valorDeA - valorDeC)) && (valorDeC < (valorDeA + valorDeB)) && (valorDeC > Math.Abs(valorDeA - valorDeB)))
            {
                if (valorDeA == valorDeB && valorDeB == valorDeC)
                    MessageBox.Show("Triângulo equilatero");
                else if (valorDeA == valorDeB || valorDeB == valorDeC || valorDeA == valorDeC)
                    MessageBox.Show("Triangulo isósceles");
                else
                    MessageBox.Show("Triângulo escaleno");

            }
            else
                MessageBox.Show("Não é triângulo");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtValorDeA_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtValorDeA.Text, out valorDeA) || valorDeA <= 0)
            {
                MessageBox.Show("Valor de A inválido");
                e.Cancel = true;
            }
        }
    }
}
