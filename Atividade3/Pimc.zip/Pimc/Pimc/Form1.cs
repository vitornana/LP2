﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso;
        double altura;
        double imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
            txtImc.Text = Convert.ToString(imc);

            if (imc < 18.5)
                MessageBox.Show("MAGREZA grau 0");
            else
                if (imc < 25)
                MessageBox.Show("NORMAL grau 0");
            else
                if (imc < 30)
                MessageBox.Show("SOBREPESO grau 1");
            else
                if (imc < 40)
                MessageBox.Show("OBESIDADE grau 2");
            else
                MessageBox.Show("OBESIDADE GRAVE grau 3");
        }

        private void mskbxPeso_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso) || Convert.ToDouble(mskbxPeso.Text) <= 0)
            {
                MessageBox.Show("Peso inválido!");
                e.Cancel = true;
            }
        }

        private void mskbxAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(mskbxAltura.Text, out altura) || Convert.ToDouble(mskbxAltura.Text) <= 0)
            {
                MessageBox.Show("Altura inválida!");
                e.Cancel = true;
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            txtImc.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
