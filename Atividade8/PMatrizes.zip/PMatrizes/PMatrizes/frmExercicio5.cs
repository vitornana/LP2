﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int raUltimoDigito = 6;
            int nAlunos = raUltimoDigito == 0 ? 2 : raUltimoDigito + 1;

            char[] gabarito = { 'A', 'B', 'C', 'D', 'A', 'B', 'C', 'D', 'A', 'B' };

            char[,] respostasAlunos = new char[nAlunos, 10];

            for (int i = 0; i < nAlunos; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string resposta;
                    do
                    {
                        resposta = Interaction.InputBox($"Digite a resposta do aluno {i + 1} para a questão {j + 1} (A, B, C ou D):", "Entrada de Respostas", "").ToUpper();
                    } while (!"ABCD".Contains(resposta) || resposta.Length != 1);

                    respostasAlunos[i, j] = resposta[0];
                }
            }

            lbxResultado.Items.Clear();
            for (int i = 0; i < nAlunos; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    bool acertou = respostasAlunos[i, j] == gabarito[j];
                    string resultado = acertou ? "acertou" : "errou";
                    lbxResultado.Items.Add($"O aluno:{i + 1} {resultado} a questão:{j + 1} era {respostasAlunos[i, j]} escolheu {gabarito[j]}");
                }
            }
        }
    }
}
