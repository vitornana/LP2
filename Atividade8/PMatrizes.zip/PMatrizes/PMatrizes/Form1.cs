﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;
using System.Web;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}° número", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("número inválido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
            {
                auxiliar += x + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList minhalista = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro" };
            minhalista.Remove("Otávio");
            string auxiliar = "";
            foreach (string nomes in minhalista)
            {
                auxiliar += nomes + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new Double[20, 3];
            string auxiliar = "";
            double media = 0;
            for (int aluno = 0; aluno < 20; aluno++)
            {
                media = 0;
                for (int nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {nota + 1} do {aluno + 1}° aluno", "Entrada de dados");
                    if (!double.TryParse(auxiliar, out notas[aluno, nota]) || notas[aluno, nota] < 0 || notas[aluno, nota] > 10)
                    {
                        MessageBox.Show("número inválido");
                        nota--;
                    }
                    media += notas[aluno, nota];
                }
                MessageBox.Show($"A média do {aluno + 1}° aluno é: {media / 3}");
            }
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 obj1 = new frmExercicio4();
                //obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }

            /*String[] nome = new string[200];
            String auxiliar = "";

            for (int i = 0; i < 10; i ++)
            {
                auxiliar = Interaction.InputBox($"Digite o nome completo da pessoa {i}", "Entrada de dados");
                
            }
            */

        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 obj1 = new frmExercicio5();
                //obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }
    }
}