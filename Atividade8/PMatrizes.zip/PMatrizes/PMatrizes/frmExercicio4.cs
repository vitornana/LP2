﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[200];
            int[] tamanhos = new int[200];

            for (int i = 0; i < 10; i++)
            {
                string nome = Interaction.InputBox($"Digite o nome completo da pessoa {i + 1}:", "Entrada de Nomes", "");

                nomes[i] = nome;

                int tamanhoSemEspacos = nome.Replace(" ", "").Length;

                tamanhos[i] = tamanhoSemEspacos;
            }

            lbxNomes.Items.Clear();
            for (int i = 0; i < 10; i++)
            {
                lbxNomes.Items.Add($"O nome:{nomes[i]} tem {tamanhos[i]} caracteres");
            }
        }
    }
}
