﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            lbxResultado.Items.Clear();
            string aux = "";
            string saida = "";
            int filme, pessoa;
            double[,] notas = new double[2, 2];
            double media1 = 0;
            double media2 = 0;
            double operacao = 0;


            for (filme = 0; filme < 2; filme++)
            {
                for (pessoa = 0; pessoa < 2; pessoa++)
                {
                    aux = Interaction.InputBox($"Digite a nota para o {filme + 1}° filme", "Entrada de dados");
                    if (!double.TryParse(aux, out notas[filme, pessoa]) || notas[filme, pessoa] < 0 || notas[filme, pessoa] > 10)
                    {
                        MessageBox.Show("Nota inválida, tente novamente!");
                        pessoa--;
                    }
                    else
                    {
                        operacao += notas[filme, pessoa];
                    }
                }
            }

            media1 = (notas[0, 0] + notas[0, 1]) / 2;
            media2 = (notas[1, 0] + notas[1, 1]) / 2;

            
            for (pessoa = 0; pessoa < 2; pessoa++)
            {
                saida += $"\nPessoa {pessoa + 1} - Nota filme 1: {notas[0, pessoa]} / Nota filme 2: {notas[1, pessoa]}";
            }

            
            for (pessoa = 0; pessoa < 2; pessoa++)
            {
                lbxResultado.Items.Add($"Pessoa {pessoa + 1} - Nota filme 1: {notas[0, pessoa].ToString("N2")} / Nota filme 2: {notas[1, pessoa].ToString("N2")}");
            }

            lbxResultado.Items.Add("----------------------------------------------------------");
            lbxResultado.Items.Add($"Média filme 1: {media1.ToString("N2")}");
            lbxResultado.Items.Add($"Média filme 2: {media2.ToString("N2")}");



        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbxResultado.Items.Clear();
        }
    }
}
